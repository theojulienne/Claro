import _claro, cairo, math

def on_quit(o, e):
	_claro.shutdown()

def on_redraw(o, e):
	cr = o.cr
	cr.scale(300, 300)
	
	cr.select_font_face ("Sans", cairo.FONT_SLANT_NORMAL, cairo.FONT_WEIGHT_BOLD)
	cr.set_font_size (0.3)

	cr.move_to (0.035, 0.53)
	cr.show_text ("Hello")

	cr.move_to (0.22, 0.65)
	cr.text_path ("void")
	cr.set_source_rgb (0.5,0.5,1)
	cr.fill_preserve ()
	cr.set_source_rgb (0,0,0)
	cr.set_line_width (0.01)
	cr.stroke ()

	#/* draw helping lines */
	cr.set_source_rgba (1,0.2,0.2, 0.6)
	cr.arc (0.04, 0.53, 0.02, 0, 2* math.pi)
	cr.arc (0.27, 0.65, 0.02, 0, 2* math.pi)
	cr.fill ()

b = _claro.Bounds(0, 0, 300, 300)
w = _claro.Window(None, b, 0, "Claro Test")
c = _claro.Canvas(w, _claro.Bounds(0,0,300,300), 0)

w.addhandler("destroy", on_quit)
c.addhandler("redraw", on_redraw)

w.show()

_claro.loop()
